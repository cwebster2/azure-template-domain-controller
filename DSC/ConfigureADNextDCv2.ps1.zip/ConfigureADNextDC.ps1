﻿configuration ConfigureADNextDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        
        [Parameter(Mandatory)]
        [String]$DNSServer,

        [Parameter(Mandatory)]
        [String]$DNSForwarder,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xStorage, cDisk, xNetworking, ComputerManagementDsc

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    Node localhost
    {
        [ScriptBlock]$SetScript =
        {
            Set-DnsClientServerAddress -InterfaceAlias ("$InterfaceAlias") -ServerAddresses ("$PrimaryDcIpAddress")
        }

        PowerShellExecutionPolicy SetExecutionPolicyUnrestricted
        {
            ExecutionPolicyScope = 'LocalMachine'
            ExecutionPolicy = 'Unrestricted'
        }

        Script SetDnsServerAddressToFindPDC
        {
            GetScript = {return @{}}
            TestScript = {return $false} # Always run the SetScript for this.
            SetScript = $SetScript.ToString().Replace('$PrimaryDcIpAddress', $DNSServer).Replace('$InterfaceAlias', $InterfaceAlias)
            DependsOn = "[PowerShellExecutionPolicy]SetExecutionPolicyUnrestricted"
        }

        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        Script SetTimeZone
        {
          SetScript = 
          {
            Set-TimeZone -Id "Eastern Standard Time"
          }
          GetScript =  { @{} }
          TestScript = { $false }
          DependsOn = "[PowerShellExecutionPolicy]SetExecutionPolicyUnrestricted"
        }

        Script DisableIESecurity
        {
          SetScript = 
          {
            $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
            $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
            Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
            Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0
            Stop-Process -Name Explorer
          }
          GetScript =  { @{} }
          TestScript = { $false }
          DependsOn = "[PowerShellExecutionPolicy]SetExecutionPolicyUnrestricted"
        }
        
        Script DisableFeedback
        {
          SetScript = 
          {
            New-Item -ErrorAction SilentlyContinue -Path "HKCU:SOFTWARE\Microsoft\Siuf\Rules" -Force | Out-Null
            Set-ItemProperty -ErrorAction SilentlyContinue -Path "HKCU:SOFTWARE\Microsoft\Siuf\Rules" -Name NumberOfSIUFInPeriod -Value 0 -Force | Out-Null
            if ((Get-ItemProperty -Path "HKCU:SOFTWARE\Microsoft\Siuf\Rules" -Name PeriodInNanoSeconds -ErrorAction SilentlyContinue) -ne $null) 
            { 
              Remove-ItemProperty -Path "HKCU:SOFTWARE\Microsoft\Siuf\Rules" -Name PeriodInNanoSeconds 
            }
          }
          GetScript =  { @{} }
          TestScript = { $false }
          DependsOn = "[PowerShellExecutionPolicy]SetExecutionPolicyUnrestricted"
        }

        Script DisableUpdates
        {
          SetScript = 
          {
            Set-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU -Name NoAutoUpdate -Value 1
          }
          GetScript =  { @{} }
          TestScript = { $false }
          DependsOn = "[PowerShellExecutionPolicy]SetExecutionPolicyUnrestricted"
        }

        WindowsFeature DNS
        {
            Ensure = "Present"
            Name = "DNS"
            IncludeAllSubFeature = $true
        }

        WindowsFeature DnsTools
        {
            Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
        }
        
        WindowsFeature ADTools
        {
            Ensure = "Present"
            Name = "RSAT-AD-Tools"
            DependsOn = "[WindowsFeature]DNS"
        }
        
        WindowsFeature GPOTools
        {
            Ensure = "Present"
            Name = "GPMC"
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature DFSTools
        {
            Ensure = "Present"
            Name = "RSAT-DFS-Mgmt-Con"
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskId = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }
        
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitForDisk]Disk2"
        }
        
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
            DependsOn = "[cDiskNoRestart]ADDataDisk"
        }
        
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn="[Script]SetDnsServerAddressToFindPDC"
        }
        
        xADDomainController NextDC
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = @("[xWaitForADDomain]DscForestWait", "[WindowsFeature]ADDSInstall")
        }

        # Now make sure this computer uses itself as a DNS source
        xDnsServerAddress UpdateDnsServerAddress
        {
            Address        = @('127.0.0.1', $DNSServer)
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn="[xADDomainController]NextDC"
        }

        PendingReboot Reboot1
        {
            Name = "RebootServer"
            DependsOn = "[xDnsServerAddress]UpdateDnsServerAddress"
        }

    }
}
